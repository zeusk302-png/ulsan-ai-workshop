울산대학교 AI 실습 공식 원문 자료 목록
전체 PDF는 발행기관에서 내려받으세요. 기본 묶음: 편람PDF·업무계획PDF·noticeTXT·regulationTXT·rulesTXT.
complaintsTXT는2026.12.3. 시행예정본 비교용으로 기본 묶음에 넣지 않습니다.
빈 신청서에는 실제 주민번호·계좌번호를 입력하지 않습니다.

2025 행정업무운영 편람
https://www.mois.go.kr/frt/bbs/type001/commonSelectBoardArticle.do?bbsId=BBSMSTR_000000000012&nttId=122878
전체 원문: https://www.mois.go.kr/cmm/fms/FileDown.do?atchFileId=FILE_00141723RKL5RWf&fileSn=0
원문은 발행기관에서 내려받습니다. 2025년 편람의 설명과 이후 법령 개정 내용을 구분하세요.

2026년 큰꿈 작은학교(주민강사) 지원사업 공고
https://www.junggu.ulsan.kr/edu/community/community01.do?bid=BD000015&bmidx=3490&exec=view
전체 원문: https://www.junggu.ulsan.kr/edu/file/boardFileDown.do?bid=BD000015&bmidx=3490&fNo=0
접수 종료된 공고를 교육용으로 분석합니다. 빈 서식에 실제 주민번호·계좌번호를 입력하지 마세요.

2026년 2월 3~4주 주간업무계획
https://www.bukgu.ulsan.kr/lay1/bbs/S1T62C110/A/28/view.do?article_seq=311506
전체 원문: https://www.bukgu.ulsan.kr/download.do?uuid=b20aaec9-a7b2-4b68-8375-544fdf24dda8.pdf
2026년 2월의 당시 계획 자료입니다. 계획과 실제 완료를 구분하고, 수치·시간 이상 여부는 PDF와 대조하세요.

행정업무의 운영 및 혁신에 관한 규정
https://www.law.go.kr/LSW/lsInfoP.do?lsiSeq=290525
전체 원문: https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=290525&efYd=20261002&chrClsCd=010202
2026-10-14 수집한 법령 전문입니다. 부칙·미시행 조문 표시를 함께 읽고 실제 업무 적용 시 원문을 다시 확인하세요.

행정업무의 운영 및 혁신에 관한 규정 시행규칙
https://www.law.go.kr/LSW/lsInfoP.do?lsiSeq=252189
전체 원문: https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=252189&efYd=20230628&chrClsCd=010202
별표·서식은 본문 텍스트와 구분해 공식 원문에서 확인하세요. 수집일 기준 버전을 표시합니다.

민원 처리에 관한 법률 · 시행예정본 비교
https://www.law.go.kr/LSW/lsInfoP.do?lsiSeq=286421
전체 원문: https://www.law.go.kr/LSW/lsInfoR.do?lsiSeq=286421&efYd=20261203&chrClsCd=010202
2026-12-03 시행예정본입니다. 수집일 2026-10-14에는 아직 시행 전이므로 현행 근거로 사용하지 않습니다.